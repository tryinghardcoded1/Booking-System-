<?php

/**
 * Default config values.
 */
return [
    'bootstrapVersion' => '3.3.4',
    'jqueryVersion'    => '2.1.0',
    'icon_prefix'      => 'glyphicon',
];
