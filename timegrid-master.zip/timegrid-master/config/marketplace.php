<?php

/**
 * Timegrid Marketplace Related
 */
return [

    'pricing' => [
        'currency_price' => env('MARKETPLACE_CURRENCY_PRICE', 'SOON'),
    ],

];
