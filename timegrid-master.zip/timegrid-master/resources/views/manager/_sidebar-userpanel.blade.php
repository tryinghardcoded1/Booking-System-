<!-- Sidebar user panel (optional) -->
<div class="user-panel">
    <div class="pull-left image">
        <img src="{{ $gravatarURL }}" class="img-circle" alt="{{ $user->name }}">
    </div>
    <div class="pull-left info">
        <p>{{ $user->name }}&nbsp;&nbsp;<i class="fa fa-circle text-success"></i></p>        
    </div>
</div>