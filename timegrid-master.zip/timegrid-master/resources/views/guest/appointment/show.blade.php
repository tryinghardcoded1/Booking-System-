@extends('layouts.user')

@section('content')

    {!! $appointment->panel() !!}

@endsection
