<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/12/09 15:37:10
*************************************************************************/

return [
  'feature' => [
    1 => [
      'content' => 'Allows your clients to choose when to book.',
      'title'   => 'Optimize',
    ],
    2 => [
      'content' => 'Keep all your contacts together and get new subscribers.',
      'title'   => 'Annuitize',
    ],
    3 => [
      'content' => 'Provide a better service to your customers.',
      'title'   => 'Professionalize',
    ],
    4 => [
      'content' => 'It\'s time to enjoy the saved time and take your vacations.',
      'title'   => 'Liberate',
    ],
  ],
  'jumbotron' => [
    'btn' => [
      'begin' => 'Let\'s begin',
      'login' => 'Login',
    ],
    'description' => 'The booking app for successful service professionals.',
    'title'       => 'timegrid.io',
  ],
];
