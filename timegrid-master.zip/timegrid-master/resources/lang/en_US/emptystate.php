<?php

return  [
  'manager' => [
    'appointments' => [
      'title' => 'Your schedule is empty',
      'hint'  => 'Share your timegrid page to your clients to start taking reservations.',
    ],
  ],
];
