<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/07/20 17:32:03
*************************************************************************/

return [
  'alert'    => 'Well done! Please tell us what would you like to do',
  'business' => [
    'btn'     => 'I want to provide services',
    'header'  => 'I run a business',
    'caption' => 'Do you need to provide online appointments for your services? Register your business and start giving bookings today.',
  ],
  'user' => [
    'btn'     => 'I want to make reservations',
    'header'  => 'I am a customer',
    'caption' => 'Do you need to make a reservation for a service?',
  ],
];
