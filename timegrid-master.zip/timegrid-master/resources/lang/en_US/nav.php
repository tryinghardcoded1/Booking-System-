<?php

return  [
  //============================== New strings to translate ==============================//
  'manager' =>  [
    'left' =>  [
      'dashboard'     => 'Dashboard',
      'notifications' => 'Notifications',
      'preferences'   => 'Preferences',
      'edit'          => 'Edit',
      'addressbook'   => 'Addressbook',
      'agenda'        => 'Agenda',
      'availability'  => 'Availability',
      'calendar'      => 'Calendar',
      'services'      => 'Services',
      'staff'         => 'Staff',
    ],
  ],
];
