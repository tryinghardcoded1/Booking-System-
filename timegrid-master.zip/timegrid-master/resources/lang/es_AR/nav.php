<?php

return  [
  //============================== New strings to translate ==============================//
  'manager' =>  [
    'left' =>  [
      'dashboard'     => 'Panel',
      'notifications' => 'Notificaciones',
      'preferences'   => 'Preferencias',
      'edit'          => 'Editar',
      'addressbook'   => 'Contactos',
      'agenda'        => 'Turnos',
      'availability'  => 'Disponibilidad',
      'calendar'      => 'Agenda',
      'services'      => 'Servicios',
      'staff'         => 'Staff',
    ],
  ],
];
