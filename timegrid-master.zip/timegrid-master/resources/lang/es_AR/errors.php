<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/12/02 23:47:14
*************************************************************************/

return [
  403 => [
    'description' => '403 - Lo siento.',
  ],
  404 => [
    'description' => '404... por donde se fue?',
  ],
];
