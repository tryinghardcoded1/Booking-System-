<?php

return  [

  'btn' => [
    'edit'   => 'Editar Tipos de Servicio',
    'update' => 'Actualizar',
  ],

  'title' => [
    'edit' => 'Editar Tipos de Servicio',
  ],

  'msg' => [
    'update' => [
        'success' => 'Tipos de servicio actualizados!',
    ],
  ],

];
