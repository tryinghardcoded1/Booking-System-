<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/12/09 15:37:10
*************************************************************************/

return [
  'feature' => [
    1 => [
      'content' => 'Le da los turnos automáticamente a tus clientes para que pases menos tiempo al teléfono acordando horarios.',
      'title'   => 'Organiza turnos',
    ],
    2 => [
      'content' => 'Pedir turno ahora es tan fácil que tus clientes no ponen más excusas para no venir o reagendarte a tiempo.',
      'title'   => 'Fideliza clientes',
    ],
    3 => [
      'content' => 'Ser constante y mantener un orden de trabajo es una clave de éxito. Tus clientes merecen el mejor servicio.',
      'title'   => 'Te profesionaliza',
    ],
    4 => [
      'content' => 'Ahora podés irte de vacaciones y volver con la tranquilidad de que tu agenda está lista para empezar a trabajar.',
      'title'   => 'Te libera',
    ],
  ],
  'jumbotron' => [
    'btn' => [
      'begin' => 'Soy nuevo',
      'login' => 'Ya tengo cuenta',
    ],
    'description' => 'Turnos por Internet para profesionales exitosos.',
    'title'       => 'timegrid.io',
  ],
];
