<?php

return  [

  'btn' => [
    'edit'   => 'Modifica i tipi di servizio',
    'update' => 'Aggiorna',
  ],

  'title' => [
    'edit' => 'Modifica i tipi di servizio',
  ],

  'msg' => [
    'update' => [
        'success' => 'Tipi di servizio aggiornati!',
    ],
  ],

];
