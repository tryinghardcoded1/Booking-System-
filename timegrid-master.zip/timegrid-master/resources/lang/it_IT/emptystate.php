<?php

return  [
  'manager' => [
    'appointments' => [
      'title' => 'Non hai nessun appuntamento al momento',
      'hint'  => 'Condividi la tua pagina timegrid ai vostri clienti per iniziare a prendere le prenotazioni.',
    ],
  ],
];
