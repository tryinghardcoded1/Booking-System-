<?php

return  [
  //============================== New strings to translate ==============================//
  'manager' =>  [
    'left' =>  [
      'dashboard'     => 'Dashboard',
      'notifications' => 'Notifications',
      'preferences'   => 'Préférences',
      'edit'          => 'Modifier',
      'addressbook'   => 'Carnet d\'adresses',
      'agenda'        => 'Agenda',
      'availability'  => 'Disponibilité',
      'calendar'      => 'Calendrier',
      'services'      => 'Services',
      'staff'         => 'Equipe',
    ],
  ],
];
