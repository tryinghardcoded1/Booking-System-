<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2015/12/09 15:37:10
*************************************************************************/

return [
  'feature' => [
    1 => [
      'content' => 'Permettre à vos clients de choisir leur date de réservation.',
      'title'   => 'Optimiser',
    ],
    2 => [
      'content' => 'Gardez tous vos contacts ensemble et obtenez de nouveaux abonnés.',
      'title'   => 'Annuler',
    ],
    3 => [
      'content' => 'Offrir un meilleur service à vos clients.',
      'title'   => 'Professionnaliser',
    ],
    4 => [
      'content' => 'Profiter du gain de temps et prennez vos vacances.',
      'title'   => 'Libérer',
    ],
  ],
  'jumbotron' => [
    'btn' => [
      'begin' => 'Commençons',
      'login' => 'Connexion',
    ],
    'description' => 'L\'application de réservation pour les professionnels des services réussis.',
    'title'       => 'timegrid.io',
  ],
];
