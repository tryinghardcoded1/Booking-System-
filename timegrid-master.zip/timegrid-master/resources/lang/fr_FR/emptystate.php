<?php

return  [
  'manager' => [
    'appointments' => [
      'title' => 'Vous n\'avez auncun rendez-vous',
      'hint'  => 'Partagez votre page timegrid avec vos clients pour commencer à prendre des réservations.',
    ],
  ],
];
